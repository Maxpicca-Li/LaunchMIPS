# Sirius
Asymmetric dual issue in-order microprocessor.

## Plan

- [x] Sirius alpha before 27 May, 2019 -- SRAM func test.
- [x] Sirius alpha before 7 June, 2019 -- AXI func test & perf_test.
- [ ] Sirius beta before 12 July, 2019. -- True dual-issue.
- [ ] Sirius beta before 20 August, 2019. -- Hello, linux!

![](http://florin.myip.org/blog/files/640px-Sirius_A_and_B_artwork.jpg)
